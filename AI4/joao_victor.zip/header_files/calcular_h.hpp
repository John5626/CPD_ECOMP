#pragma once

#include <array>
#include "avl.hpp"
#include "abb.hpp"

std::array<int, 2> calcular_h(no_abb*& r_abb, no_avl*& r_avl, int tam);