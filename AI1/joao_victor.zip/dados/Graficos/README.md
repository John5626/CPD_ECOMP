JOAO VICTOR SOUZA - ECOMP - CPD - AI1
Obs.: Encontrei um código em phyton que possibilitava juntar todos os dados.
     A imagem 'comparativo.png' foi feita com esse codigo.

     Não entendi o motivo do gráfico de Heapsort ter dado aquele formato já que ele
     é n*log(n). Pelo gráfico comparativo aparenta ser quase que constante. 
     Testei com vetores maiores e não havia mudado muito o formato. 
     A imagem 'heap2.png' foi feita com os dados de um desses testes, mas para efeito comparativo mantive
     a imagem com os mesmo n para os outros gráficos.

     